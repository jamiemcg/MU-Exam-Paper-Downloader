To run, open the file "exam_papers.exe"

This will save the exam papers to the current folder (that of the program)